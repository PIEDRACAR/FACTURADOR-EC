(function () {
  // Compatibilidad móvil: evita zoom automático de inputs y conserva el layout
  // estable en Android/iOS sin alterar la lógica funcional de los módulos.
  const metaViewport = document.querySelector('meta[name="viewport"]');
  if (!metaViewport) {
    const m = document.createElement('meta');
    m.name = 'viewport';
    m.content = 'width=device-width, initial-scale=1, viewport-fit=cover';
    document.head?.appendChild(m);
  }
  if (window.__CONTSERTRIB_SHELL_LOADED__) return;
  window.__CONTSERTRIB_SHELL_LOADED__ = true;
  document.documentElement.classList.add('ec-shell-loading');
  const SHELL_VERSION = '9.9.87';
  const path = location.pathname.replace(/\/$/, '') || '/';
  const isProtectedPage = path !== '/login' && path !== '/registro';
  const qs = new URLSearchParams(location.search);
  let emisorId = qs.get('emisorId') || localStorage.getItem('facturador_emisor_id') || '';
  // Failsafe móvil: nunca dejamos la pantalla bloqueada en estado loading.
  // Esto cubre navegadores móviles lentos, restauración desde caché y errores
  // transitorios de JavaScript/red.
  const shellWatchdog = window.setTimeout(() => {
    document.documentElement.classList.remove('ec-shell-loading');
    document.documentElement.classList.add('ec-shell-degraded');
  }, 3500);

  const modulo = [
    ['/', 'home', 'Inicio'], ['/pos', 'invoice', 'Facturación'], ['/proformas', 'file', 'Proformas'],
    ['/productos-admin', 'box', 'Productos'], ['/inventario', 'inventory', 'Inventario'],
    ['/clientes-admin', 'users', 'Clientes'], ['/proveedores-admin', 'truck', 'Proveedores'],
    ['/caja', 'cash', 'Caja'], ['/contabilidad', 'chart', 'Contabilidad'], ['/cuentas-por-cobrar', 'receive', 'Cuentas por cobrar'],
    ['/cuentas-por-pagar', 'pay', 'Cuentas por pagar'], ['/reportes', 'chart', 'Reportes'],
    ['/usuarios-admin', 'user', 'Usuarios'], ['/correo-prueba', 'mail', 'Correo'], ['/ats', 'chart', 'ATS'], ['/configuracion', 'settings', 'Configuración']
  ];
  const nombres = Object.fromEntries(modulo.map(x => [x[0], x[2]]));

  function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
  function link(href) { return href + (href.includes('?') ? '&' : '?') + 'emisorId=' + encodeURIComponent(emisorId || ''); }
  function icon(name, cls='') {
    const paths = {
      home:'<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V20h13v-9.5"/><path d="M9.5 20v-5h5v5"/>',
      invoice:'<path d="M6 3.5h9l3 3V21H6z"/><path d="M15 3.5V7h3"/><path d="M9 11h6M9 14.5h6M9 18h3"/>',
      file:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h6"/>',
      box:'<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z"/><path d="m4 7.5 8 4.5 8-4.5M12 12v9"/>',
      inventory:'<path d="M4 5h16v15H4z"/><path d="M8 9h8M8 13h8M8 17h5"/>',
      users:'<circle cx="9" cy="8" r="3"/><path d="M3.5 20c.7-3.5 2.5-5.5 5.5-5.5s4.8 2 5.5 5.5"/><path d="M16 11a3 3 0 1 0 0-6M16 14.5c2.4.1 3.8 1.9 4.5 5.5"/>',
      truck:'<path d="M3 6h11v10H3zM14 10h4l3 3v3h-7z"/><circle cx="7" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',
      cash:'<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 9h.01M18 15h.01"/>',
      receive:'<path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h4"/><path d="m16 15 2 2-2 2"/>',
      pay:'<path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h4"/><path d="m16 17-2-2 2-2"/>',
      chart:'<path d="M4 19V5M4 19h17"/><path d="m7 15 4-5 3 3 5-7"/>',
      user:'<circle cx="12" cy="8" r="3.5"/><path d="M5 21c.8-4.1 3.1-6.2 7-6.2s6.2 2.1 7 6.2"/>',
      mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/>',
      settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.8 1.8 0 0 0 .3 2l.1.1-1.9 1.9-.1-.1a1.8 1.8 0 0 0-2-.3 1.8 1.8 0 0 0-1.1 1.7V21h-2.7v-.7a1.8 1.8 0 0 0-1.1-1.7 1.8 1.8 0 0 0-2 .3l-.1.1-1.9-1.9.1-.1a1.8 1.8 0 0 0 .3-2 1.8 1.8 0 0 0-1.7-1.1H5v-2.7h.7A1.8 1.8 0 0 0 7.4 10a1.8 1.8 0 0 0-.3-2L7 7.9 8.9 6l.1.1a1.8 1.8 0 0 0 2 .3 1.8 1.8 0 0 0 1.1-1.7V4h2.7v.7a1.8 1.8 0 0 0 1.1 1.7 1.8 1.8 0 0 0 2-.3l.1-.1L20 7.9l-.1.1a1.8 1.8 0 0 0-.3 2 1.8 1.8 0 0 0 1.7 1.1h.7v2.7h-.7a1.8 1.8 0 0 0-1.9 1.2Z"/>',
      bell:'<path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
      search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
      menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',
      sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.65 17.65l1.42 1.42M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.65 6.35l1.42-1.42"/>',
      moon:'<path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 8.5 8.5 0 1 0 20.5 15.5Z"/>',
      chevron:'<path d="m8 10 4 4 4-4"/>',
      logout:'<path d="M10 5H5v14h5M14 8l4 4-4 4M18 12H9"/>'
    };
    return `<svg class="ec-svg ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.file}</svg>`;
  }

  function negocioPlaceholder() {
    return {
      emisorId: emisorId || '',
      nombreComercial: 'Mi negocio',
      razonSocial: 'Mi negocio',
      ruc: '',
      usuarioNombre: 'Usuario',
      rol: 'Administrador',
      __placeholder: true
    };
  }

  async function obtenerSesion() {
    const r = await fetch('/auth/yo', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } });
    if (r.status === 401) {
      location.href = '/login';
      return null;
    }
    if (!r.ok) throw new Error(`No se pudo validar la sesión (HTTP ${r.status}).`);
    const data = await r.json();
    return data;
  }

  let ultimoHeartbeat=Date.now();
  setInterval(async()=>{try{const r=await fetch('/auth/yo',{credentials:'same-origin',headers:{'Accept':'application/json'}});if(r.ok)ultimoHeartbeat=Date.now();else if(r.status===401 && Date.now()-ultimoHeartbeat>120000)location.href='/login';}catch(_e){}},120000);

  function actualizarShell(negocio) {
    const nombre = negocio?.nombreComercial || negocio?.razonSocial || 'Mi negocio';
    const ruc = negocio?.ruc || '';
    document.querySelectorAll('[data-ec-business-name]').forEach(el => { el.textContent = nombre; });
    document.querySelectorAll('[data-ec-business-ruc]').forEach(el => { el.textContent = ruc ? `RUC ${ruc}` : 'RUC configurado'; });
    document.querySelectorAll('[data-ec-user-name]').forEach(el => { el.textContent = negocio?.usuarioNombre || 'Usuario'; });
    document.querySelectorAll('[data-ec-user-role]').forEach(el => { el.textContent = negocio?.rol || 'Administrador'; });
    const avatar = (negocio?.usuarioNombre || negocio?.rol || 'U').slice(0,1).toUpperCase();
    document.querySelectorAll('[data-ec-avatar]').forEach(el => { el.textContent = avatar; });
    // Rehidrata los enlaces del shell con el emisor real. Esto evita que el
    // primer render (placeholder) deje enlaces sin emisorId cuando el login
    // todavía está resolviéndose.
    document.querySelectorAll('.ec-sidebar a[href], .ec-mobile-nav a[href], .ec-user-panel a[href]').forEach(a => {
      const href = a.getAttribute('href') || '';
      if (!href || href === '#') return;
      try {
        const u = new URL(href, location.origin);
        if (u.origin !== location.origin) return;
        u.searchParams.set('emisorId', emisorId);
        a.setAttribute('href', u.pathname + u.search + u.hash);
      } catch (_) {}
    });
    document.documentElement.classList.remove('ec-shell-loading');
    document.documentElement.classList.add('ec-shell-ready');
    window.clearTimeout(shellWatchdog);
  }

  function prepararShellInmediato() {
    if (!isProtectedPage || document.querySelector('.ec-sidebar')) return;
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', () => prepararShellInmediato(), { once: true });
      return;
    }
    try { renderShell(negocioPlaceholder()); }
    catch (error) {
      document.documentElement.classList.remove('ec-shell-loading');
      document.documentElement.classList.add('ec-shell-degraded');
      window.clearTimeout(shellWatchdog);
      console.warn('[CONTSERTRIB] Shell visual no disponible:', error);
    }
  }

  async function resolveBusiness() {
    if (!isProtectedPage) return;
    prepararShellInmediato();
    try {
      const data = await obtenerSesion();
      if (!data) return;
      const negocios = Array.isArray(data.negocios) ? data.negocios : [];
      const elegido = negocios.find(n => n.emisorId === emisorId) ||
        negocios.find(n => n.emisorId === localStorage.getItem('facturador_emisor_id')) ||
        negocios[0];
      if (!elegido) {
        document.documentElement.classList.remove('ec-shell-loading');
        document.documentElement.classList.add('ec-shell-ready');
        return;
      }
      emisorId = elegido.emisorId;
      localStorage.setItem('facturador_emisor_id', emisorId);
      if (path !== '/' && !qs.get('emisorId')) {
        const u = new URL(location.href);
        u.searchParams.set('emisorId', emisorId);
        location.replace(u.toString());
        return;
      }
      actualizarShell(elegido);
      window.dispatchEvent(new CustomEvent('contsertrib:shell-ready', { detail: { negocio: elegido, emisorId } }));
    } catch (error) {
      // La interfaz NO desaparece si auth/backend tarda o falla.
      // Las pantallas existentes siguen siendo responsables de sus datos.
      document.documentElement.classList.remove('ec-shell-loading');
      document.documentElement.classList.add('ec-shell-degraded');
      console.warn('[CONTSERTRIB] No se pudo hidratar el negocio activo:', error);
    }
  }

  function renderShell(negocio) {
    if (!document.body || document.querySelector('.ec-sidebar')) return;
    const active = path;
    const navLink = ([href,ic,label]) => `<a class="${active===href.split('?')[0]?'active':''}" href="${link(href)}" data-label="${esc(label)}"><span class="ec-menu-icon">${icon(ic)}</span><span class="ec-menu-label">${esc(label)}</span></a>`;
    const aside = document.createElement('aside');
    aside.className = 'ec-sidebar';
    aside.innerHTML = `
      <div class="ec-brand"><div class="ec-brand-icon">${icon('invoice')}</div><div><strong>CONTSERTRIB FACTURACIÓN</strong><small>Sistema de Facturación Electrónica</small></div></div>
      <div class="ec-business"><small>NEGOCIO ACTIVO</small><strong data-ec-business-name>${esc(negocio.nombreComercial || negocio.razonSocial || 'Mi empresa')}</strong><span data-ec-business-ruc>${negocio.ruc ? `RUC ${esc(negocio.ruc)}` : 'RUC configurado'}</span></div>
      <nav class="ec-menu" aria-label="Navegación principal">
        <div class="ec-menu-section"><span>Inicio y ventas</span></div>
        <div class="ec-menu-group">${modulo.slice(0,4).map(navLink).join('')}</div>
        <div class="ec-menu-section"><span>Gestión comercial</span></div>
        <div class="ec-menu-group">${[modulo[4],modulo[5],modulo[6]].map(navLink).join('')}</div>
        <div class="ec-menu-section"><span>Finanzas y contabilidad</span></div>
        <div class="ec-menu-group">${[modulo[7],['/caja','cash','Caja'],['/contabilidad','chart','Contabilidad'],['/cuentas-por-cobrar','receive','Cuentas por cobrar'],['/cuentas-por-pagar','pay','Cuentas por pagar'],['/reportes','chart','Reportes'],['/ats','chart','ATS']].filter((item,i,a)=>item && a.findIndex(x=>x[0]===item[0])===i).map(navLink).join('')}</div>
        <div class="ec-menu-section"><span>Administración</span></div>
        <div class="ec-menu-group">${navLink(['/usuarios-admin','user','Usuarios'])}${navLink(['/correo-prueba','mail','Correo'])}${navLink(['/configuracion','settings','Configuración'])}</div>
      </nav>
      <div class="ec-sidebar-foot"><div class="ec-company-mini"><span>${icon('box')}</span><div><strong data-ec-business-name>${esc(negocio.nombreComercial || negocio.razonSocial || 'Mi empresa')}</strong><small data-ec-business-ruc>${negocio.ruc ? `RUC: ${esc(negocio.ruc)}` : 'RUC configurado'}</small></div></div><a href="#" id="ec-cambiar-negocio">⇄ Cambiar negocio</a><a href="#" id="ec-salir">${icon('logout')} Cerrar sesión</a></div>`;
    document.body.prepend(aside);
    const overlay = document.createElement('div'); overlay.className='ec-sidebar-overlay'; overlay.id='ec-sidebar-overlay'; document.body.appendChild(overlay);
    document.body.classList.add('ec-shell-active');

    let header = document.querySelector('body > header');
    if (!header) { header = document.createElement('header'); document.body.prepend(header); }
    header.className = 'ec-topbar';
    header.innerHTML = `<button class="ec-menu-toggle" id="ec-menu-toggle" aria-label="Abrir menú">${icon('menu')}</button><div class="ec-head-logo"><div class="ec-brand-icon">${icon('invoice')}</div><b>CONTSERTRIB FACTURACIÓN</b></div><label class="ec-search"><span>${icon('search')}</span><input id="ec-global-search" placeholder="Buscar facturas, clientes, productos..." autocomplete="off"></label><div class="ec-head-spacer"></div><button class="ec-head-business" id="ec-business-button"><span class="ec-head-business-icon">${icon('box')}</span><span><strong data-ec-business-name>${esc(negocio.nombreComercial || negocio.razonSocial || 'Mi empresa')}</strong><small data-ec-business-ruc>${negocio.ruc ? `RUC ${esc(negocio.ruc)}` : 'RUC configurado'}</small></span>${icon('chevron','ec-caret')}</button><button class="ec-top-action ec-notify" id="ec-notify-button" type="button" title="Notificaciones" aria-label="Abrir notificaciones" data-action="notifications" aria-expanded="false"><span class="ec-action-icon">${icon('bell')}</span><b id="ec-notify-count">0</b></button><button class="ec-top-action ec-theme-button" id="ec-theme-button" type="button" title="Cambiar tema" aria-label="Cambiar entre tema claro y oscuro"><span class="ec-action-icon" id="ec-theme-icon">${icon('moon')}</span></button><button class="ec-top-action ec-head-user ec-user-button" id="ec-user-button" type="button" title="Menú de usuario" aria-label="Abrir menú de usuario" data-action="user" aria-expanded="false"><span class="ec-avatar ec-avatar-user-icon" data-ec-avatar>${icon('user')}</span><span class="ec-user-info"><strong data-ec-user-name>${esc(negocio.usuarioNombre || 'Usuario')}</strong><small data-ec-user-role>${esc(negocio.rol || 'Administrador')}</small></span>${icon('chevron','ec-caret')}</button>`;

    const title = nombres[path] || 'Módulo';
    if (path !== '/' && !document.querySelector('.ec-page-heading')) {
      const cont = document.querySelector('.contenedor');
      if (cont) { const h=document.createElement('div'); h.className='ec-page-heading'; h.innerHTML=`<div><div class="ec-breadcrumb">Inicio <span>›</span> ${esc(title)}</div><h1>${esc(title)}</h1><p>Administra y consulta la información de tu negocio desde un solo lugar.</p></div><div class="ec-heading-actions"></div>`; cont.prepend(h); }
    }

    const mobileNav=document.createElement('nav'); mobileNav.className='ec-mobile-nav'; mobileNav.innerHTML=modulo.slice(0,4).map(([href,ic,label])=>`<a class="${active===href?'active':''}" href="${link(href)}">${icon(ic)}<span>${esc(label)}</span></a>`).join('')+`<button id="ec-mobile-more">${icon('menu')}<span>Más</span></button>`; document.body.appendChild(mobileNav);

    const closeMenu=()=>document.body.classList.remove('ec-sidebar-open');
    document.getElementById('ec-menu-toggle')?.addEventListener('click',()=>document.body.classList.toggle('ec-sidebar-open'));
    overlay.addEventListener('click',closeMenu);
    document.querySelectorAll('.ec-sidebar a').forEach(a=>a.addEventListener('click',closeMenu));
    document.getElementById('ec-mobile-more')?.addEventListener('click',()=>document.body.classList.toggle('ec-sidebar-open'));
    document.getElementById('ec-salir')?.addEventListener('click',async e=>{e.preventDefault();await fetch('/auth/logout',{method:'POST'});localStorage.removeItem('facturador_emisor_id');location.href='/login';});
    document.getElementById('ec-cambiar-negocio')?.addEventListener('click',async e=>{e.preventDefault();const r=await fetch('/auth/yo');const d=await r.json();if((d.negocios||[]).length<=1)return alert('Tu usuario solo tiene un negocio asociado.');const opts=d.negocios.map((n,i)=>`${i+1}. ${n.nombreComercial||n.razonSocial}`).join('\n');const n=prompt('Selecciona el número del negocio:\n\n'+opts);const i=Number(n)-1;if(d.negocios[i]){localStorage.setItem('facturador_emisor_id',d.negocios[i].emisorId);const u=new URL(location.href);u.searchParams.set('emisorId',d.negocios[i].emisorId);location.href=u.toString();}});
    document.getElementById('ec-business-button')?.addEventListener('click',()=>document.getElementById('ec-cambiar-negocio')?.click());
    const globalSearch=document.getElementById('ec-global-search');
    const searchBox=document.createElement('div'); searchBox.id='ec-global-search-results'; searchBox.className='ec-search-results'; searchBox.hidden=true; document.body.appendChild(searchBox);
    let searchTimer=0, searchAbort=null;
    function cerrarBusqueda(){searchBox.hidden=true;searchBox.classList.remove('open');}
    function pintarResultados(data,q){
      const groups=[['Facturas',data.facturas||[],x=>`<a href="/comprobantes/${encodeURIComponent(x.id)}/ride" target="_blank" rel="noopener"><strong>Factura ${esc(x.numero||x.secuencial||'')}</strong><small>${esc(x.cliente||'')} · $${Number(x.total||0).toFixed(2)} · Abrir PDF</small></a>`],['Asientos contables',data.asientos||[],x=>`<a href="${link('/contabilidad')}&asientoId=${encodeURIComponent(x.id)}"><strong>${esc(x.tipo||'Asiento')} · ${esc(x.concepto||'')}</strong><small>${esc(x.fecha||'')} · Debe $${Number(x.debe||0).toFixed(2)} / Haber $${Number(x.haber||0).toFixed(2)}</small></a>`],['Clientes',data.clientes||[],x=>`<a href="${link('/clientes-admin')}&buscar=${encodeURIComponent(x.identificacion||x.razon_social||'')}"><strong>${esc(x.razon_social||'Cliente')}</strong><small>${esc(x.identificacion||'')}</small></a>`],['Productos',data.productos||[],x=>`<a href="${link('/productos-admin')}&buscar=${encodeURIComponent(x.codigo_principal||x.descripcion||'')}"><strong>${esc(x.descripcion||'Producto')}</strong><small>${esc(x.codigo_principal||'')} · $${Number(x.precio_venta||0).toFixed(2)}</small></a>`]];
      const total=groups.reduce((n,g)=>n+g[1].length,0); if(!total){searchBox.innerHTML='<div class="ec-search-empty">Sin resultados para <strong>'+esc(q)+'</strong></div>';searchBox.hidden=false;searchBox.classList.add('open');return;}
      searchBox.innerHTML=groups.filter(g=>g[1].length).map(g=>`<section><h4>${g[0]}</h4>${g[1].map(g[2]).join('')}</section>`).join('')+`<button type="button" class="ec-search-all">Ver resultados completos</button>`;
      searchBox.querySelector('.ec-search-all')?.addEventListener('click',()=>location.href=link('/reportes')+'&q='+encodeURIComponent(q)); searchBox.hidden=false;searchBox.classList.add('open');
    }
    async function buscarGlobal(q){
      if(!emisorId||q.length<2){cerrarBusqueda();return;} if(searchAbort) searchAbort.abort(); searchAbort=new AbortController();
      searchBox.innerHTML='<div class="ec-search-empty">Buscando…</div>'; searchBox.hidden=false;searchBox.classList.add('open');
      try{const r=await fetch('/buscar-global?emisorId='+encodeURIComponent(emisorId)+'&q='+encodeURIComponent(q),{credentials:'same-origin',signal:searchAbort.signal});const d=await r.json();if(!r.ok)throw Error(d.error||'No se pudo buscar.');pintarResultados(d,q);}catch(e){if(e.name!=='AbortError')searchBox.innerHTML='<div class="ec-search-empty">No se pudo realizar la búsqueda.</div>';}
    }
    globalSearch?.addEventListener('input',e=>{clearTimeout(searchTimer);const q=e.target.value.trim();searchTimer=window.setTimeout(()=>void buscarGlobal(q),180);});
    globalSearch?.addEventListener('focus',()=>{if(globalSearch.value.trim().length>=2)void buscarGlobal(globalSearch.value.trim());});
    globalSearch?.addEventListener('keydown',e=>{if(e.key==='Enter'){const v=globalSearch.value.trim();if(v)location.href=link('/reportes')+'&q='+encodeURIComponent(v);}if(e.key==='Escape')cerrarBusqueda();});
    document.addEventListener('click',e=>{if(!e.target.closest('.ec-search')&&!e.target.closest('#ec-global-search-results'))cerrarBusqueda();});
    // Centro de notificaciones + menú de usuario (v9.9.17)
    // Implementado con delegación y pointerdown/click para que los controles
    // sigan funcionando aunque otras pantallas modifiquen el DOM del encabezado.
    const popoverBackdrop = document.createElement('div');
    popoverBackdrop.id = 'ec-popover-backdrop';
    popoverBackdrop.className = 'ec-popover-backdrop';
    popoverBackdrop.hidden = true;
    document.body.appendChild(popoverBackdrop);

    const panel = document.createElement('div');
    panel.id='ec-notify-panel';
    panel.className='ec-popover ec-notify-panel';
    panel.setAttribute('role','dialog');
    panel.setAttribute('aria-label','Centro de notificaciones');
    panel.innerHTML='<div class="ec-popover-head"><div><strong>Centro de notificaciones</strong><small>Alertas y eventos de tu negocio</small></div><button id="ec-read-all" type="button">Marcar todas como leídas</button></div><div id="ec-notify-list" class="ec-notify-list"><div class="ec-notify-empty">Cargando…</div></div>';
    document.body.appendChild(panel);

    const themeButton=document.getElementById('ec-theme-button');
    const themeIcon=document.getElementById('ec-theme-icon');
    function aplicarTema(tema){
      const oscuro=tema==='dark';
      document.documentElement.setAttribute('data-theme',oscuro?'dark':'light');
      localStorage.setItem('contsertrib_theme',oscuro?'dark':'light');
      if(themeIcon) themeIcon.innerHTML=icon(oscuro?'sun':'moon');
      if(themeButton){themeButton.title=oscuro?'Usar tema claro':'Usar tema oscuro';themeButton.setAttribute('aria-label',themeButton.title);}
    }
    const temaGuardado=localStorage.getItem('contsertrib_theme');
    aplicarTema(temaGuardado==='dark'?'dark':'light');
    themeButton?.addEventListener('click',()=>aplicarTema(document.documentElement.getAttribute('data-theme')==='dark'?'light':'dark'));

    const userPanel = document.createElement('div');
    userPanel.id='ec-user-panel';
    userPanel.className='ec-popover ec-user-panel';
    userPanel.setAttribute('role','menu');
    userPanel.setAttribute('aria-label','Menú de usuario');
    const esAdmin = String(negocio.rol || '').toLowerCase() === 'admin';
    userPanel.innerHTML=`<div class="ec-user-panel-head"><span class="ec-avatar ec-avatar-large ec-avatar-user-icon" data-ec-avatar>${icon('user')}</span><div><strong data-ec-user-name>${esc(negocio.usuarioNombre || 'Usuario')}</strong><small data-ec-user-role>${esc(negocio.rol || 'Administrador')}</small></div></div>${esAdmin ? `<a href="${link('/usuarios-admin')}" data-user-action="usuarios">👥 Gestión de usuarios</a>` : ''}<a href="${link('/configuracion')}" data-user-action="configuracion">⚙ Configuración</a><button id="ec-user-logout" type="button" data-user-action="logout">↪ Cerrar sesión</button>`;
    document.body.appendChild(userPanel);

    const notifyButton=document.getElementById('ec-notify-button');
    const userButton=document.getElementById('ec-user-button');
    const notifyCount=document.getElementById('ec-notify-count');

    function syncPopoverState() {
      const abierto = panel.classList.contains('open') || userPanel.classList.contains('open');
      popoverBackdrop.hidden = !abierto;
      document.body.classList.toggle('ec-popover-open', abierto);
      notifyButton?.setAttribute('aria-expanded',panel.classList.contains('open')?'true':'false');
      userButton?.setAttribute('aria-expanded',userPanel.classList.contains('open')?'true':'false');
    }
    function cerrarPopovers() {
      panel.classList.remove('open');
      userPanel.classList.remove('open');
      syncPopoverState();
    }
    function abrirNotificaciones() {
      userPanel.classList.remove('open');
      panel.classList.toggle('open');
      syncPopoverState();
      if(panel.classList.contains('open')) void renderNotifications();
    }
    function abrirUsuario() {
      panel.classList.remove('open');
      userPanel.classList.toggle('open');
      syncPopoverState();
    }

    async function fetchJson(url, options={}) {
      const r = await fetch(url, { credentials:'same-origin', ...options, headers:{ ...(options.headers||{}), 'Accept':'application/json' } });
      let d={};
      try { d=await r.json(); } catch (_) {}
      if (!r.ok) throw new Error(d.error || `Error HTTP ${r.status}`);
      return d;
    }

    function iconNotificacion(tipo, prioridad){
      if(tipo==='correo') return icon('mailAlert');
      if(tipo==='inventario') return icon('box');
      if(tipo==='sri') return icon(prioridad==='alta'?'warning':'file');
      return icon('bell');
    }

    const renderNotifications = async()=>{
      if (!emisorId) return;
      const list=document.getElementById('ec-notify-list');
      if(!list) return;
      try {
        const d=await fetchJson('/notificaciones?emisorId='+encodeURIComponent(emisorId));
        const items=Array.isArray(d.items)?d.items:[];
        if (notifyCount) {
          notifyCount.textContent=String(Number(d.noLeidas||0));
          notifyCount.style.display=Number(d.noLeidas||0)>0?'grid':'none';
        }
        if(!items.length){list.innerHTML='<div class="ec-notify-empty">✓ Todo está al día.<br><small>No tienes alertas pendientes.</small></div>';return;}
        list.innerHTML=items.map(x=>'<article class="ec-notify-item '+(x.leida?'read':'unread')+'" data-id="'+esc(x.id)+'"><span class="ec-notify-type-icon '+esc(x.prioridad)+'">'+iconNotificacion(x.tipo,x.prioridad)+'</span><div class="ec-notify-content"><div class="ec-notify-title">'+esc(x.titulo)+'</div><div class="ec-notify-detail">'+esc(x.detalle)+'</div><small>'+esc(x.fecha?new Date(x.fecha).toLocaleString('es-EC',{timeZone:'America/Guayaquil'}):'Ahora')+'</small></div><button class="ec-notify-read" type="button" title="Marcar como leída" aria-label="Marcar como leída">'+(x.leida?'✓':'○')+'</button></article>').join('');
        list.querySelectorAll('.ec-notify-read').forEach(btn=>btn.addEventListener('click',async ev=>{
          ev.preventDefault(); ev.stopPropagation();
          const item=btn.closest('.ec-notify-item'); if(!item) return;
          try { await fetchJson('/notificaciones/leer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({emisorId,notificacionId:item.dataset.id})}); await renderNotifications(); }
          catch(err) { alert(err.message || 'No se pudo marcar la notificación.'); }
        }));
        list.querySelectorAll('.ec-notify-item').forEach(item=>item.addEventListener('click',async ev=>{
          if (ev.target.closest('.ec-notify-read') || item.classList.contains('read')) return;
          try { await fetchJson('/notificaciones/leer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({emisorId,notificacionId:item.dataset.id})}); await renderNotifications(); }
          catch(err) { alert(err.message || 'No se pudo marcar la notificación.'); }
        }));
      } catch(e){
        if (notifyCount) { notifyCount.textContent='!'; notifyCount.style.display='grid'; }
        list.innerHTML='<div class="ec-notify-empty"><strong>No se pudieron cargar las notificaciones.</strong><br><small>'+esc(e?.message || 'Error de conexión con el servidor.')+'</small><br><button type="button" id="ec-notify-retry" class="ec-notify-retry">Reintentar</button></div>';
        document.getElementById('ec-notify-retry')?.addEventListener('click',()=>void renderNotifications());
      }
    };

    function manejarAccionSuperior(ev) {
      const target = ev.target instanceof Element ? ev.target : null;
      const notify = target?.closest('#ec-notify-button');
      const user = target?.closest('#ec-user-button');
      if (notify) { ev.preventDefault(); ev.stopPropagation(); if (ev.type === 'pointerdown' || ev.type === 'click') abrirNotificaciones(); return; }
      if (user) { ev.preventDefault(); ev.stopPropagation(); if (ev.type === 'pointerdown' || ev.type === 'click') abrirUsuario(); return; }
      if (target?.closest('#ec-popover-backdrop')) { ev.preventDefault(); cerrarPopovers(); return; }
      if (panel.classList.contains('open') && !target?.closest('#ec-notify-panel')) cerrarPopovers();
      else if (userPanel.classList.contains('open') && !target?.closest('#ec-user-panel')) cerrarPopovers();
    }
    // Captura el click en fase de captura: funciona aunque otro componente
    // tenga un listener que detenga la propagación. No usamos pointerdown
    // simultáneamente para evitar abrir y cerrar el panel en el mismo toque.
    document.addEventListener('click', manejarAccionSuperior, true);
    document.addEventListener('keydown', e=>{ if(e.key==='Escape') cerrarPopovers(); });

    document.getElementById('ec-read-all')?.addEventListener('click',async e=>{
      e.preventDefault(); e.stopPropagation();
      try { await fetchJson('/notificaciones/leer-todas',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({emisorId})}); await renderNotifications(); }
      catch(err) { alert(err.message || 'No se pudieron marcar las notificaciones.'); }
    });
    document.getElementById('ec-user-logout')?.addEventListener('click',async e=>{
      e.preventDefault();
      try { await fetch('/auth/logout',{method:'POST',credentials:'same-origin'}); } finally { localStorage.removeItem('facturador_emisor_id'); location.href='/login'; }
    });

    if (emisorId) void renderNotifications();
    const intervaloNotificaciones = window.setInterval(()=>{ if(!document.hidden) void renderNotifications(); },30000);
    window.addEventListener('pagehide',()=>window.clearInterval(intervaloNotificaciones),{once:true});

    }

  /**
   * Selector único de impresión para los 6 comprobantes electrónicos.
   * Solo abre recursos de lectura ya persistidos: nunca emite, firma,
   * consulta ni retransmite al SRI.
   */
  function instalarSelectorImpresion() {
    if (window.__CONTSERTRIB_PRINT_SELECTOR__) return;
    window.__CONTSERTRIB_PRINT_SELECTOR__ = true;

    const rutas = {
      factura: { a4: id => `/comprobantes/${encodeURIComponent(id)}/ride`, ticket: id => `/comprobantes/${encodeURIComponent(id)}/ticket`, nombre: 'Factura' },
      nota_credito: { a4: id => `/api/documentos/${encodeURIComponent(id)}/pdf`, ticket: id => `/api/documentos/${encodeURIComponent(id)}/ticket`, nombre: 'Nota de crédito' },
      nota_debito: { a4: id => `/api/documentos/${encodeURIComponent(id)}/pdf`, ticket: id => `/api/documentos/${encodeURIComponent(id)}/ticket`, nombre: 'Nota de débito' },
      liquidacion_compra: { a4: id => `/api/documentos/${encodeURIComponent(id)}/pdf`, ticket: id => `/api/documentos/${encodeURIComponent(id)}/ticket`, nombre: 'Liquidación de compra' },
      guia_remision: { a4: id => `/api/documentos/${encodeURIComponent(id)}/pdf`, ticket: id => `/api/documentos/${encodeURIComponent(id)}/ticket`, nombre: 'Guía de remisión' },
      retencion: { a4: id => `/api/documentos/${encodeURIComponent(id)}/pdf`, ticket: id => `/api/documentos/${encodeURIComponent(id)}/ticket`, nombre: 'Comprobante de retención' }
    };

    function abrir(tipo, id, estado='autorizado') {
      const cfg = rutas[tipo];
      if (!cfg || !id) return false;
      document.getElementById('ec-print-selector')?.remove();
      const autorizado = String(estado).toLowerCase() === 'autorizado';
      const modal = document.createElement('div');
      modal.id = 'ec-print-selector';
      modal.style.cssText = 'position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(15,23,42,.62);backdrop-filter:blur(4px);';
      modal.innerHTML = `<div role="dialog" aria-modal="true" style="width:min(560px,100%);background:#fff;border-radius:18px;padding:22px;box-shadow:0 24px 80px rgba(0,0,0,.25);font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#172033">
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:start"><div><div style="font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#64748b">CONTSERTRIB · IMPRESIÓN</div><h3 style="margin:4px 0 0;font-size:22px">${cfg.nombre}</h3></div><button type="button" data-print-close style="border:0;background:#eef2f7;border-radius:10px;padding:8px 10px;cursor:pointer;font-size:18px">×</button></div>
        <p style="color:#64748b;line-height:1.5;margin:14px 0 18px">Elige el formato. <b>RIDE A4</b> es la representación impresa del documento electrónico. <b>Ticket térmico</b> es una versión compacta para impresión rápida. ${autorizado?'':'Este documento todavía no está autorizado por el SRI.'}</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
          <button type="button" data-print-a4 style="border:1px solid #cbd5e1;background:#0f2747;color:#fff;border-radius:13px;padding:17px 14px;cursor:pointer;text-align:left"><strong style="display:block;font-size:15px">📄 RIDE A4</strong><span style="display:block;margin-top:5px;font-size:12px;opacity:.85">Formato profesional ${autorizado?'autorizado':'de borrador'} para revisar o imprimir</span></button>
          <button type="button" data-print-ticket style="border:1px solid #cbd5e1;background:#fff;color:#172033;border-radius:13px;padding:17px 14px;cursor:pointer;text-align:left"><strong style="display:block;font-size:15px">🧾 Ticket térmico</strong><span style="display:block;margin-top:5px;font-size:12px;color:#64748b">58/80 mm según la configuración de la impresora</span></button>
        </div>
        <div style="margin-top:14px;padding:10px 12px;background:#f8fafc;border-radius:10px;font-size:11px;color:#64748b">🔒 Esta acción es solo de lectura e impresión. No modifica el XML, la clave de acceso, el estado ni la transmisión al SRI.</div>
      </div>`;
      document.body.appendChild(modal);
      const cerrar=()=>modal.remove();
      modal.querySelector('[data-print-close]').onclick=cerrar;
      modal.addEventListener('click',e=>{if(e.target===modal)cerrar();});
      modal.querySelector('[data-print-a4]').onclick=()=>{cerrar();window.open(cfg.a4(id),'_blank','noopener');};
      modal.querySelector('[data-print-ticket]').onclick=()=>{cerrar();window.open(cfg.ticket(id),'_blank','noopener');};
      setTimeout(()=>modal.querySelector('[data-print-close]')?.focus(),0);
      return true;
    }

    window.CONTSERTRIB_abrirSelectorImpresion = abrir;

    // Intercepta los enlaces de impresión/RIDE existentes para que no haya
    // una ruta que salte el selector. XML y otros enlaces no se interceptan.
    document.addEventListener('click', e => {
      const target = e.target instanceof Element ? e.target.closest('a[href]') : null;
      if (!target) return;
      const href = target.getAttribute('href') || '';
      let m = href.match(/^\/comprobantes\/([^/?#]+)\/(ride|ticket)(?:[?#].*)?$/);
      if (m) {
        e.preventDefault();
        abrir('factura', decodeURIComponent(m[1]), 'autorizado');
        return;
      }
      m = href.match(/^\/api\/documentos\/([^/?#]+)\/(pdf|ticket)(?:[?#].*)?$/);
      if (m) {
        e.preventDefault();
        const estado = target.dataset.estado || (target.closest('[data-documento-estado]')?.getAttribute('data-documento-estado')) || 'autorizado';
        abrir(window.__CONTSERTRIB_DOCUMENTO_TIPO__ || new URLSearchParams(location.search).get('tipo') || 'nota_credito', decodeURIComponent(m[1]), estado);
      }
    }, true);
  }

  function addExportToolbar() {
    if (!emisorId) return;
    const cont=document.querySelector('.contenedor');if(!cont)return;
    const map={
      '/clientes-admin':['clientes','👥 Clientes'],
      '/proveedores-admin':['proveedores','🚚 Proveedores'],
      '/cuentas-por-cobrar':['cuentas-por-cobrar','💰 Cuentas por cobrar'],
      '/cuentas-por-pagar':['cuentas-por-pagar','💳 Cuentas por pagar'],
      '/caja':['caja','💵 Caja'],
      '/productos-admin':['inventario-valorizado','📦 Inventario'],
      '/proformas':['proformas','📝 Proformas']
    };
    if(!map[path]||cont.querySelector('.ec-global-export'))return;
    const [tipo,label]=map[path],base=`/reportes/exportar?emisorId=${encodeURIComponent(emisorId)}&tipo=${encodeURIComponent(tipo)}`;
    const importable=path==='/clientes-admin'||path==='/proveedores-admin';
    const endpoint=path==='/clientes-admin'?'/clientes/importar':path==='/proveedores-admin'?'/proveedores/importar':'';
    const bar=document.createElement('div');bar.className='ec-toolbar ec-global-export';bar.innerHTML=`<span class="ec-toolbar-title">${label} · consulta, exportación y respaldo</span><a class="ec-export excel" target="_blank" href="${base}&formato=excel">⬇ Excel</a><a class="ec-export pdf" target="_blank" href="${base}&formato=pdf">⬇ PDF</a><a class="ec-export" href="${link('/reportes')}&tipo=${encodeURIComponent(tipo)}">🔎 Filtros avanzados</a>${importable?`<button type="button" class="ec-export" id="ec-import-data">⬆ Importar Excel</button><input type="file" id="ec-import-file" accept=".xlsx" hidden>`:''}`;cont.prepend(bar);
    if(importable){const btn=bar.querySelector('#ec-import-data'),file=bar.querySelector('#ec-import-file');btn?.addEventListener('click',()=>file.click());file?.addEventListener('change',async()=>{const f=file.files?.[0];if(!f)return;try{const buf=await f.arrayBuffer();let bin='';const bytes=new Uint8Array(buf);for(const x of bytes)bin+=String.fromCharCode(x);const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({emisorId,archivoBase64:btoa(bin)})});const d=await r.json();if(!r.ok)throw Error(d.error||'No se pudo importar');alert(`Importación completada: ${d.importados??0} registros.`+(d.errores?.length?`\nFilas con error: ${d.errores.length}`:''));location.reload();}catch(e){alert(e.message)}finally{file.value='';}});}
  }
  document.addEventListener('DOMContentLoaded',()=>{setTimeout(addExportToolbar,120);});
  prepararShellInmediato();
  instalarSelectorImpresion();
  resolveBusiness();
})();
