import PDFDocument from 'pdfkit';

/**
 * Dibuja un PDF de tabla simple (título, columnas, filas, total opcional al
 * pie) — reutilizado por todos los reportes exportables.
 */
export async function generarPdfTabla(opciones: {
  titulo: string;
  subtitulo?: string;
  columnas: Array<{ clave: string; etiqueta: string; ancho: number; alinearDerecha?: boolean }>;
  filas: Array<Record<string, unknown>>;
  filaTotales?: Record<string, unknown>;
  empresa?: { razonSocial?: string; nombreComercial?: string; ruc?: string; direccion?: string };
}): Promise<Buffer> {
  const doc = new PDFDocument({ size: 'A4', margin: 36, layout: 'landscape' });
  const chunks: Buffer[] = [];
  doc.on('data', (chunk) => chunks.push(chunk));
  const listo = new Promise<Buffer>((resolve) => doc.on('end', () => resolve(Buffer.concat(chunks))));

  const anchoUtil = doc.page.width - 72;

  const empresa=opciones.empresa||{}; const nombre=empresa.razonSocial||empresa.nombreComercial||'CONTSERTRIB FACTURACIÓN';
  doc.rect(36,28,anchoUtil,50).fill('#0f2747'); doc.fillColor('#fff').font('Helvetica-Bold').fontSize(11).text(nombre,46,39,{width:280}); doc.font('Helvetica').fontSize(7.5).text(`RUC: ${empresa.ruc||'—'}`,46,56); if(empresa.direccion)doc.text(empresa.direccion,170,56,{width:270}); doc.font('Helvetica-Bold').fontSize(13).text(opciones.titulo,400,39,{width:160,align:'right'}); doc.fillColor('black');
  if (opciones.subtitulo) { doc.fontSize(8.5).font('Helvetica').fillColor('#64748b').text(opciones.subtitulo, 36, 86); doc.fillColor('black'); }
  let y = opciones.subtitulo ? 102 : 94;
  const dibujarCabeceraTabla=()=>{
    doc.rect(36,y,anchoUtil,18).fill('#1e3a8a'); doc.fillColor('white').fontSize(8).font('Helvetica-Bold');
    let hx=40; for(const col of opciones.columnas){doc.text(col.etiqueta,hx,y+5,{width:Math.max(20,col.ancho-4),align:col.alinearDerecha?'right':'left',lineBreak:false});hx+=col.ancho;}
    doc.fillColor('black'); y+=18;
  };
  dibujarCabeceraTabla();
  doc.font('Helvetica').fontSize(7.2);
  if (!opciones.filas.length) { doc.fillColor('#64748b').fontSize(9).text('No existen registros para los filtros seleccionados.',40,y+8,{width:anchoUtil,align:'center'}); doc.fillColor('black'); y+=30; }
  for (const fila of opciones.filas) {
    // Calcula una altura real para textos largos, evitando que cliente/concepto/
    // claves de acceso se monten sobre la fila siguiente.
    let altura=16;
    for(const col of opciones.columnas){const valor=fila[col.clave];const texto=valor==null?'':String(valor);const h=doc.heightOfString(texto,{width:Math.max(20,col.ancho-4),lineGap:1});altura=Math.max(altura,Math.min(48,h+7));}
    if (y+altura > doc.page.height-45) { doc.addPage({ size:'A4', margin:36, layout:'landscape' }); y=36; dibujarCabeceraTabla(); }
    let x=40;
    for(const col of opciones.columnas){const valor=fila[col.clave];doc.text(valor==null?'':String(valor),x,y+4,{width:Math.max(20,col.ancho-4),height:altura-5,align:col.alinearDerecha?'right':'left',lineGap:1});x+=col.ancho;}
    y+=altura; doc.moveTo(36,y).lineTo(36+anchoUtil,y).strokeColor('#e2e8f0').stroke().strokeColor('black');
  }
  if(opciones.filaTotales){
    y+=5; if(y+24>doc.page.height-45){doc.addPage({size:'A4',margin:36,layout:'landscape'});y=36;dibujarCabeceraTabla();}
    doc.rect(36,y,anchoUtil,22).fill('#eff6ff');doc.fillColor('#1e3a8a').font('Helvetica-Bold').fontSize(8.5);let x=40;
    for(const col of opciones.columnas){const valor=opciones.filaTotales[col.clave];doc.text(valor==null?'':String(valor),x,y+6,{width:Math.max(20,col.ancho-4),align:col.alinearDerecha?'right':'left',lineBreak:false});x+=col.ancho;}doc.fillColor('black');
  }

  doc.fillColor('#64748b').font('Helvetica').fontSize(7).text('CONTSERTRIB FACTURACIÓN · Reporte generado en Ecuador',36,doc.page.height-24,{width:anchoUtil,align:'center'});
  doc.end();
  return listo;
}
